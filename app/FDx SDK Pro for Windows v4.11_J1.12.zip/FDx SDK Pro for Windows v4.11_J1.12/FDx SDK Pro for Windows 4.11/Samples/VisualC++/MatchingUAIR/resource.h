//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by matchingUAIR.rc
//
#define IDD_MATCHINGUAIR_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_REGBUTTON                   1000
#define IDC_MATBUTTON                   1001
#define IDC_INITBUTTON                  1002
#define IDC_CONFBUTTON                  1003
#define IDC_REGIMAGE                    1004
#define IDC_MATIMAGE                    1005
#define IDC_EDIT1                       1006
#define IDC_REGIMAGE2                   1006
#define IDC_EDIT2                       1007
#define IDC_EDIT_USER                   1008
#define IDC_COMBO1                      1009
#define IDC_IDENTIFY                    1010
#define IDC_EDIT3                       1011
#define Device                          1012
#define IDC_COMBO_DEVICE                1013
#define IDC_COMBO_FORMAT                1014
#define IDC_PROGRESS2                   1015
#define IDC_BTN_CAPTURE_R1              1016
#define IDC_BTN_CAPTURE_REG             1017
#define IDC_BTN_CAPTURE_R2              1018
#define IDC_BTN_CAPTURE_V1              1019
#define IDC_BTN_CHANGE_FORMAT           1020
#define IDC_BTN_CLEAR_REG               1020
#define IDC_BTN_CAPTURE_R3              1021
#define IDC_CHECK1                      1022
#define IDC_REG_THUMBNAIL_1             1023
#define IDC_REG_THUMBNAIL_2             1024
#define IDC_REG_THUMBNAIL_3             1025
#define IDC_REG_THUMBNAIL_4             1026
#define IDC_REG_THUMBNAIL_5             1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
